from .BluetoothInterface import BluetoothInterface

def register_all():
    return BluetoothInterface.register_all()
