from .common import platform, getplatform, Platform
from .permissions import RuntimePermission
